# grupo

Nicolas Boni - RM551965 - ESPV
Kaue Pastori -RM98501 - ESPV

# Como acessar o projeto

Para acessar o projeto, siga estas etapas:

Inicialização do Servidor e Aplicativo:

Abra o terminal.
Execute npm run backend para iniciar o Json.server, habilitando o acesso ao banco de dados.
Em seguida, execute npm run dev para iniciar o aplicativo.
Registro de Usuário:

Acesse a página de registro.
Preencha as informações solicitadas: ID, nome, e-mail e senha.
Conclua o registro para criar suas credenciais de acesso.
Login:

Na página de login, insira seu e-mail e senha.
Clique em "Entrar" para acessar a página principal (Home).
Navegação:

Explore as funcionalidades disponíveis na Home.
Navegue pelas diferentes seções para conhecer todas as características do aplicativo.
Logout:

Para sair da sua conta, localize e clique em "Sair" no Navbar.
Cada passo foi desenhado para garantir uma experiência de usuário fluida e eficiente, facilitando o acesso e a interação com o projeto.

